package com.nwmsu.DMS.repository;

import org.springframework.data.repository.CrudRepository;

import com.nwmsu.DMS.Models.Trainer;

public interface TrainerRepository extends CrudRepository<Trainer, Integer> {

	
	
}
